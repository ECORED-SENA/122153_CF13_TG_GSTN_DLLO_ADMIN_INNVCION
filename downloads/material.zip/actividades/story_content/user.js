function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6abiio4p7yM":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

